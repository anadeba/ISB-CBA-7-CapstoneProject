model_XGboost = function(model_data_subset){
  library(data.table)
  library(xgboost)
  library(caret)
  library(ROSE)
  
  INCLUDE_VARS = c("DiscountPercentage","ReturnReason","OverallProdRating","PromisedSLA","DeliveryTAT","OverallSellerRating","SellerTier","DeliveryFee","CSTAT","CSContacted","PromiseUpdateFlag","NewCustomer","return_item_status","return_action","RTOReasonAttribution","return_reason_bucket","Breach","ReturnedFlag","RTOed","TRRFlag","RRFlag")
  TARGET_VAR = 'Churn'
  RUN_FOR_LIM = 0  ## set = 1 to run for limited set of variables
  
  #load('model_data_final.rda')
  set.seed(1)
  random_vector = runif(nrow(model_data))
  train_data = model_data[random_vector <= 0.7, !TARGET_VAR, with = F]
  if (RUN_FOR_LIM == 1) {
    train_data = train_data[, INCLUDE_VARS, with = F]
  }
  train_y = model_data[[TARGET_VAR]][random_vector <= 0.7]
  train_y = as.integer(train_y)-1
  test_data = model_data[random_vector > 0.7, !TARGET_VAR, with = F]
  if (RUN_FOR_LIM == 1) {
    test_data = test_data[, INCLUDE_VARS, with = F]
  }
  test_y = model_data[[TARGET_VAR]][random_vector > 0.7]
  test_y = as.integer(test_y)-1
  
  train_x = model.matrix(~ . + 0, data = train_data)
  test_x = model.matrix(~ . + 0, data = test_data)
  
  dtrain = xgb.DMatrix(data = train_x, label = train_y)
  dtest = xgb.DMatrix(data = test_x, label = test_y)
  
  params <- list(booster = "gbtree", objective = "binary:logistic", eta=0.1, gamma = 0, max_depth = 6, min_child_weight = 1, subsample = 1, colsample_bytree = 1)
  xgbcv <- xgb.cv(params = params, data = dtrain, nrounds = 2000, nfold = 5, showsd = T, stratified = T, print_every_n = 1, early_stopping_rounds = 20, maximize = F)
  opt_nrounds = which.min(xgbcv$evaluation_log$test_error_mean)
  
  xgb1 <- xgb.train(params = params, data = dtrain, nrounds = opt_nrounds*2, watchlist = list(val = dtest, train = dtrain), print_every_n = 1, early_stopping_rounds = 10, maximize = F, eval_metric = c("error", "auc"))
  xgbpred = predict(xgb1, dtest)
  xgbpred <- ifelse(xgbpred > 0.5, 1, 0)
  
  
  cm = table(test_y,as.numeric(xgbpred))
  
  TN = cm[1,1]
  TP = cm[2,2]
  FP = cm[1,2]
  FN = cm[2,1]
  Total = sum(cm)
  
  precision = (TP/(TP+FP))*100   ###Positive Predictive Value
  sensitivity = (TP/(TP+FN))*100 ###Recall/ True positive rate
  specificity = (TN/(TN+FP))*100 ### True negative rate
  accuracy = ((TP+TN)/Total)*100
  roccurve <- roc(model_data_subset_test$Churn ~ predict)
  auc = (auc(roccurve))*100
  png(filename="LR_ROC.png")
  plot(roccurve)
  dev.off()
  model_output = list("precision" = precision,"sensitivity" = sensitivity,"specificity" = specificity, "accuracy" = accuracy, "auc" = auc)
  return (model_output)
  
}

