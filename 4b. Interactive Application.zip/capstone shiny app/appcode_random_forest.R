model_random_forest = function(model_data_subset){
  
  library(randomForest)
  #model_data_subset = model_data[model_data[['Persona']] == 'Single_Working_Male']
  model_data_subset$Churn = droplevels(model_data_subset)$Churn
  
  ### Train - Test split
  
  smp_size <- floor(0.75 * nrow(model_data_subset))
  set.seed(123)
  train_ind <- sample(seq_len(nrow(model_data_subset)), size = smp_size)
  
  model_data_subset_train <- model_data_subset[train_ind, ]
  model_data_subset_test <- model_data_subset[-train_ind, ]
  
  ### The Model
  rf.model = randomForest(Churn ~., data = model_data_subset_train, importance = TRUE)
  
  ## Confusion Matrix and accuracy
  predict <- predict(rf.model, model_data_subset_test, type = 'response')
  cm = table(model_data_subset_test$Churn,predict)
  TN = cm[1,1]
  TP = cm[2,2]
  FP = cm[1,2]
  FN = cm[2,1]
  Total = sum(cm)
  
  precision = (TP/(TP+FP))*100   ###Positive Predictive Value
  sensitivity = (TP/(TP+FN))*100 ###Recall/ True positive rate
  specificity = (TN/(TN+FP))*100 ### True negative rate
  accuracy = ((TP+TN)/Total)*100
  roccurve <- roc(model_data_subset_test$Churn ~ predict)
  auc = (auc(roccurve))*100
  png(filename="LR_ROC.png")
  plot(roccurve)
  dev.off()
  model_output = list("precision" = precision,"sensitivity" = sensitivity,"specificity" = specificity, "accuracy" = accuracy, "auc" = auc)
  return (model_output)
  
}


