### Source files

source("appcode_logistic_regression.R")
source("appcode_random_forest.R")
source("appcode_xgboost.R")

### load libraries

library(data.table)
library(h2o)
library(sys)
library(ROSE)
#library(randomForest)
#library(xgboost)
#library(caret)
#library(pROC)


subset_data_and_run = function(parameter,filter_on,model_name){
  
 
  if (parameter == 'All' | filter_on == 'All'){
    model_data_subset = model_data
    #return(model_data_subset)
  }
  else{
    #model_data_subset = model_data
    model_data_subset = model_data[model_data[[parameter]] == filter_on]
  }
  
  
  
  if (model_name == 'Random Forest'){
    model_output_rf = model_random_forest(model_data_subset)
    return(data.frame(model_output_rf))
  }
  else if (model_name == 'XGBoost'){
    
    model_output_xgb = model_XGboost(model_data_subset)
    return(data.frame(model_output_xgb))
  }
  else {
      
    model_output_lr = model_logistic_regression(model_data_subset)
    return(data.frame(model_output_lr))
  }
  


}

#x = subset_data_and_run("Persona","Single_Working_Male","Random Forest")


