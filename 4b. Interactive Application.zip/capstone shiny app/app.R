#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(DT)

source("appcode.R")
load(file = "model_data_final.Rda")
load(file = "choices.Rda")

# Define UI for application that draws a histogram
ui <- shinyUI(fluidPage(
  
  # Application title
  titlePanel("Seed Application"),
  
  fluidRow(
    
    column(2,
      selectInput("model", "Model:",
                  c("Random Forest" = "Random Forest",
                  "XGBoost" = "XGBoost",
                  "Logstic Regression" = "Logistic Regression"
                  ))
          ),
    
    column(2,  
      selectInput("parameter", "Parameter:",
                   c("All" = "All",
                     "Sales Channel" = "SalesChannel",
                     "Service Profile" = "ServiceProfile",
                     "City Tier" = "CityTier",
                     "Business Unit" = "BusinessUnit",
                     "persona" = "Persona",
                     "Payment Method" = "PaymentMethod",
                     "New Customer" = "NewCustomer"))
          ),
  
    column(2,
           uiOutput("choice")
         )),
  
    
    fluidRow(
      div(style = "position:absolute;right:1em;"),
      textOutput("result"),
      actionButton("button", "Run")
      ),
  
  fluidRow(
    dataTableOutput("data")
  )
  
))


# Define server logic required to draw a histogram
server <- shinyServer(function(input, output) {
  
  output$choice <- renderUI({
    selectInput("choice", "Choice:", as.list(choices[input$parameter]))
  })
  
  output$result <- renderText({
    paste("I want to run", input$model,"algorithm for",input$choice," under ",input$parameter)
  })
  
  
  dataset = eventReactive(input$button, {
    subset_data_and_run(input$parameter,input$choice,input$model)
  })
  
  
  output$data <- DT::renderDataTable({
    dataset()
  })
  
  
})


# Run the application 
shinyApp(ui = ui, server = server)

