model_logistic_regression = function(model_data_subset){
  
  library(caret)
  library(pROC)
  
  model_data_subset$Churn = droplevels(model_data_subset)$Churn
  
  ### Train - Test split
  
  smp_size <- floor(0.75 * nrow(model_data_subset))
  set.seed(123)
  train_ind <- sample(seq_len(nrow(model_data_subset)), size = smp_size)
  
  model_data_subset_train <- model_data_subset[train_ind, ]
  model_data_subset_test <- model_data_subset[-train_ind, ]
  
  ### The Model
  logistic.model<-glm(Churn ~DiscountPercentage+ReturnReason+OverallProdRating+PromisedSLA+OverallSellerRating+SellerTier+DeliveryFee+CSTAT+CSContacted+PromiseUpdateFlag+NewCustomer+RTOReasonAttribution+Breach+TRRFlag, data = model_data_subset_train,family = "binomial")
  #summary(logistic.model)
  
  ## Confusion Matrix and accuracy
  predict <- predict(logistic.model, model_data_subset_test, type = 'response')
  cm = table(model_data_subset_test$Churn,predict > 0.5)
  TN = cm[1,1]
  TP = cm[2,2]
  FP = cm[1,2]
  FN = cm[2,1]
  Total = sum(cm)
  
  precision = (TP/(TP+FP))*100   ###Positive Predictive Value
  sensitivity = (TP/(TP+FN))*100 ###Recall/ True positive rate
  specificity = (TN/(TN+FP))*100 ### True negative rate
  accuracy = ((TP+TN)/Total)*100
  roccurve <- roc(model_data_subset_test$Churn ~ predict)
  auc = (auc(roccurve))*100
  png(filename="LR_ROC.png")
  plot(roccurve)
  dev.off()
  model_output = list("precision" = precision,"sensitivity" = sensitivity,"specificity" = specificity, "accuracy" = accuracy, "auc" = auc)
  return (model_output)
  
}

